---
type: lecture
date: 2018-09-16T8:00:00+4:30
title: Sample Lecture
tldr: "Short text to discribe what this lecture is about."
thumbnail: /static_files/presentations/lec.jpg
links: 
    - url: /static_files/presentations/lec.zip
      name: notes
    - url: /static_files/presentations/code.zip
      name: codes
    - url: https://google.com
      name: slides
---
**Suggested Readings:**
- [Readings 1](http://example.com)
- [Readings 2](http://example.com)

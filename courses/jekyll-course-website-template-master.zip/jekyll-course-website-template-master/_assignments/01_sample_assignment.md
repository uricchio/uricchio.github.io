---
type: assignment
date: 2018-09-26T4:00:00+4:30
title: 'Assignment #1 - Sample Assignment'
pdf: /static_files/assignments/asg.pdf
attachment: /static_files/assignments/asg.zip
solutions: /static_files/assignments/asg_solutions.pdf
due_event: 
    type: due
    date: 2018-11-13T23:59:00+3:30
    description: 'Assignment #1 due'
---
This is a sample assignment.

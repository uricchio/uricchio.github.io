---
type: raw_event
date: 2019-01-26T08:00:00+3:30
name: Session
description: 'Sample Raw Event'
hide_from_announcments: true
---

---
type: exam
date: 2018-12-02T8:0:0+3:30
description: 'Midterm'
hide_from_announcments: true
---
**Topics:**
1. Topic 1
2. Topic 2
3. Topic 3

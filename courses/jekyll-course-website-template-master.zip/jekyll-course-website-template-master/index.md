---
layout: home
---
Register to our [Google groups page](https://groups.google.com/forum/#!forum/gp-id) to get course notifications via email.